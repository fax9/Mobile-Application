import 'dart:async';
import 'package:flutter/material.dart';
import 'effects.dart';

void main() {
  runApp(const ScrollingListsApp());
}

class ScrollingListsApp extends StatelessWidget {
  const ScrollingListsApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Scrolling Lists and Effects',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurpleAccent),
        useMaterial3: true,
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF6C63FF),
          foregroundColor: Colors.white,
          elevation: 3,
        ),
      ),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with TickerProviderStateMixin {
  final List<_ProcessItem> items =
  List.generate(12, (i) => _ProcessItem('P${i + 1}', duration: (i % 5) + 1));
  final GlobalKey<AnimatedListState> _animatedListKey = GlobalKey();
  late AnimationController _shimmerController;

  final PageController _pageController = PageController(viewportFraction: 0.85);

  @override
  void initState() {
    super.initState();
    _shimmerController = AnimationController.unbounded(vsync: this)
      ..repeat(min: 0.0, max: 1.0, period: const Duration(seconds: 2));
  }

  @override
  void dispose() {
    _shimmerController.dispose();
    _pageController.dispose();
    super.dispose();
  }

  void _insertItem() {
    final newItem =
    _ProcessItem('P${items.length + 1}', duration: (items.length % 5) + 1);
    items.insert(0, newItem);
    _animatedListKey.currentState?.insertItem(0,
        duration: const Duration(milliseconds: 450));
  }

  void _removeItem() {
    if (items.isEmpty) return;
    final removed = items.removeAt(0);
    _animatedListKey.currentState?.removeItem(
      0,
          (context, animation) => SizeTransition(
        sizeFactor: animation,
        child: _buildProcessTile(removed, animation: animation),
      ),
      duration: const Duration(milliseconds: 400),
    );
  }

  Widget _buildProcessTile(_ProcessItem p, {Animation<double>? animation}) {
    final child = ListTile(
      leading: CircleAvatar(
        backgroundColor: Colors.deepPurple.shade300,
        foregroundColor: Colors.white,
        child: Text(p.id.replaceAll('P', '')),
      ),
      title: Text('Process ${p.id}',
          style: const TextStyle(fontWeight: FontWeight.w600)),
      subtitle: Text('Burst time: ${p.duration} units'),
      trailing: const Icon(Icons.chevron_right, color: Colors.deepPurple),
    );

    if (animation != null) {
      return FadeScaleTransition(animation: animation, child: child);
    }
    return child;
  }

  Widget _buildVerticalList() {
    return _gradientCard(
      title: "Vertical List",
      child: SizedBox(
        height: 320,
        child: ListView.separated(
          padding: const EdgeInsets.all(8),
          itemCount: items.length,
          separatorBuilder: (context, index) => const Divider(height: 8),
          itemBuilder: (context, index) {
            final p = items[index];
            return ListTile(
              leading: CircleAvatar(
                backgroundColor: Colors.purpleAccent,
                child: Text(p.id.replaceAll('P', '')),
              ),
              title: Text('Process ${p.id}',
                  style: const TextStyle(fontWeight: FontWeight.w500)),
              subtitle:
              Text('Arrival: ${p.arrival}  Burst: ${p.duration} units'),
              trailing: Text('Priority ${p.priority}',
                  style: const TextStyle(color: Colors.deepPurple)),
            );
          },
        ),
      ),
    );
  }

  Widget _buildHorizontalList() {
    return _gradientCard(
      title: "Horizontal List",
      child: SizedBox(
        height: 160,
        child: ListView.builder(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.all(12),
          itemCount: items.length,
          itemBuilder: (context, index) {
            final p = items[index];
            return Container(
              width: 140,
              margin: const EdgeInsets.only(right: 12),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                gradient: const LinearGradient(
                  colors: [Color(0xFF8E2DE2), Color(0xFF4A00E0)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
              child: Stack(
                children: [
                  Positioned.fill(
                    child: Align(
                      alignment: Alignment.center,
                      child: Text(
                        'Process ${p.id}',
                        style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                            fontSize: 16),
                      ),
                    ),
                  ),
                  AnimatedBuilder(
                    animation: _shimmerController,
                    builder: (context, child) {
                      return SimpleGradientOverlay(
                          progress: (_shimmerController.value % 1.0),
                          child: Container());
                    },
                  )
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _buildSliverList() {
    return _gradientCard(
      title: "Sliver List",
      child: SizedBox(
        height: 260,
        child: CustomScrollView(
          slivers: [
            const SliverAppBar(
              pinned: true,
              backgroundColor: Color(0xFF6C63FF),
              flexibleSpace:
              FlexibleSpaceBar(title: Text('Sliver Process List')),
            ),
            SliverList(
              delegate: SliverChildBuilderDelegate(
                    (context, index) {
                  final p = items[index % items.length];
                  return ListTile(
                    leading: CircleAvatar(
                      backgroundColor: Colors.deepPurpleAccent,
                      child: Text(p.id.replaceAll('P', '')),
                    ),
                    title: Text('Process ${p.id}'),
                    subtitle:
                    Text('Burst: ${p.duration}  Priority: ${p.priority}'),
                  );
                },
                childCount: items.length,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAnimatedList() {
    return _gradientCard(
      title: "Animated List",
      child: SizedBox(
        height: 280,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              child: Row(
                children: [
                  ElevatedButton.icon(
                      onPressed: _insertItem,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.deepPurpleAccent,
                      ),
                      icon: const Icon(Icons.add),
                      label: const Text('Insert')),
                  const SizedBox(width: 10),
                  ElevatedButton.icon(
                      onPressed: _removeItem,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.purpleAccent,
                      ),
                      icon: const Icon(Icons.remove),
                      label: const Text('Remove')),
                ],
              ),
            ),
            Expanded(
              child: AnimatedList(
                key: _animatedListKey,
                initialItemCount: items.length,
                itemBuilder: (context, index, animation) {
                  final p = items[index];
                  return SizeTransition(
                    sizeFactor: animation,
                    child: _buildProcessTile(p, animation: animation),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPageView() {
    return _gradientCard(
      title: "Page View (Parallax)",
      child: SizedBox(
        height: 240,
        child: PageView.builder(
          controller: _pageController,
          itemCount: items.length,
          itemBuilder: (context, index) {
            return _ParallaxPage(
              controller: _pageController,
              index: index,
              child: _pageCard(items[index]),
            );
          },
        ),
      ),
    );
  }

  Widget _pageCard(_ProcessItem p) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 12),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFF8E2DE2), Color(0xFF4A00E0)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              CircleAvatar(
                radius: 30,
                backgroundColor: Colors.white,
                foregroundColor: Colors.deepPurple,
                child: Text(p.id.replaceAll('P', '')),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Process ${p.id}',
                        style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: Colors.white)),
                    const SizedBox(height: 6),
                    Text('Burst time: ${p.duration}',
                        style: const TextStyle(color: Colors.white70)),
                    Text('Arrival time: ${p.arrival}',
                        style: const TextStyle(color: Colors.white70)),
                  ],
                ),
              ),
              Text('Prio ${p.priority}',
                  style:
                  const TextStyle(fontWeight: FontWeight.bold, color: Colors.white)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildResultsSummary() {
    return _gradientCard(
      title: "Simulation Summary",
      child: const ListTile(
        title: Text('Simulation Summary'),
        subtitle: Text(
            'Use lists and views above to visualize process ordering and effects.'),
      ),
    );
  }

  Widget _gradientCard({required String title, required Widget child}) {
    return Card(
      elevation: 4,
      margin: const EdgeInsets.all(12),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xFF6C63FF), Color(0xFF8E2DE2)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
            ),
            padding: const EdgeInsets.all(10),
            child: Text(title,
                style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 16)),
          ),
          child,
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final widgets = [
      const Padding(
        padding: EdgeInsets.all(12),
        child: Text('🌟 Scrolling Lists and Animated Effects',
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
      ),
      _buildVerticalList(),
      _buildHorizontalList(),
      _buildSliverList(),
      _buildAnimatedList(),
      _buildPageView(),
      _buildResultsSummary(),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('✨ Scrolling Lists & Effects')),
      body: ListView(children: widgets),
    );
  }
}

class _ParallaxPage extends StatefulWidget {
  final Widget child;
  final PageController controller;
  final int index;

  const _ParallaxPage({
    Key? key,
    required this.child,
    required this.controller,
    required this.index,
  }) : super(key: key);

  @override
  State<_ParallaxPage> createState() => _ParallaxPageState();
}

class _ParallaxPageState extends State<_ParallaxPage> {
  double _page = 0.0;
  late final VoidCallback _listener;

  @override
  void initState() {
    super.initState();
    _listener = () {
      if (!mounted) return;
      final p = widget.controller.hasClients
          ? widget.controller.page ?? widget.controller.initialPage.toDouble()
          : 0.0;
      setState(() => _page = p);
    };
    widget.controller.addListener(_listener);
  }

  @override
  void dispose() {
    widget.controller.removeListener(_listener);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final scrollPercent = (_page - widget.index);
    return ParallaxContainer(
      scrollPercent: scrollPercent,
      depth: 40,
      child: widget.child,
    );
  }
}

class _ProcessItem {
  final String id;
  final int duration;
  final int arrival;
  final int priority;

  _ProcessItem(this.id,
      {required this.duration, this.arrival = 0, this.priority = 1});
}
