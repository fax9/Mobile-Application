// lib/models/device.dart
import 'dart:convert';

class Device {
  String name;
  String type; // "Light", "Fan", "AC", "Camera"
  bool status;
  double intensity; // brightness / speed / temperature

  Device({
    required this.name,
    required this.type,
    this.status = false,
    this.intensity = 50,
  });

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'type': type,
      'status': status,
      'intensity': intensity,
    };
  }

  factory Device.fromMap(Map<String, dynamic> map) {
    return Device(
      name: map['name'] ?? '',
      type: map['type'] ?? 'Light',
      status: map['status'] ?? false,
      intensity: (map['intensity'] is int)
          ? (map['intensity'] as int).toDouble()
          : (map['intensity'] as double?) ?? 50.0,
    );
  }

  String toJson() => jsonEncode(toMap());

  factory Device.fromJson(String source) =>
      Device.fromMap(jsonDecode(source));
}
