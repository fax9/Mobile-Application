// lib/screens/dashboard_screen.dart
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'modeldevice.dart';
import 'adddevicescreen.dart';
import 'devicedetailscreen.dart';
import 'devicecard.dart';

class DashboardScreen extends StatefulWidget {
  DashboardScreen({Key? key}) : super(key: key);

  @override
  DashboardScreenState createState() => DashboardScreenState();
}

class DashboardScreenState extends State<DashboardScreen> {
  List<Device> devices = [];

  @override
  void initState() {
    super.initState();
    _loadDevices();
  }

  Future<void> _loadDevices() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList('devices_v1');

    if (raw != null) {
      setState(() => devices = raw.map((j) => Device.fromJson(j)).toList());
    } else {
      devices = [
        Device(name: 'Living Room Light', type: 'Light', status: true, intensity: 80),
        Device(name: 'Bedroom Fan', type: 'Fan', status: false, intensity: 30),
        Device(name: 'Kitchen AC', type: 'AC', status: true, intensity: 22),
        Device(name: 'Front Door Cam', type: 'Camera', status: true, intensity: 100),
      ];
      _saveDevices();
    }
  }

  Future<void> _saveDevices() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(
      'devices_v1',
      devices.map((d) => d.toJson()).toList(),
    );
  }

  IconData _iconForType(String t) {
    switch (t) {
      case 'Light':
        return Icons.lightbulb_outline;
      case 'Fan':
        return Icons.toys;
      case 'AC':
        return Icons.ac_unit;
      case 'Camera':
        return Icons.videocam;
      default:
        return Icons.devices_other;
    }
  }

  void _openAddDevice() async {
    final Device? newDevice =
    await Navigator.push(context, MaterialPageRoute(builder: (_) => AddDeviceScreen()));

    if (newDevice != null) {
      setState(() => devices.add(newDevice));
      await _saveDevices();
    }
  }

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    final crossAxisCount = width > 900 ? 4 : width > 650 ? 3 : 2;

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(icon: Icon(Icons.menu), onPressed: () {}),
        title: Text('Smart Home Dashboard'),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 12),
            child: CircleAvatar(
              backgroundColor: Colors.deepPurple.shade50,
              child: Icon(Icons.person, color: Colors.deepPurple),
            ),
          )
        ],
      ),

      body: Padding(
        padding: const EdgeInsets.all(12),

        child: Column(
          children: [
            Card(
              child: ListTile(
                title: Text('Welcome back!', style: TextStyle(fontWeight: FontWeight.w600)),
                subtitle: Text('Control your smart devices easily.'),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      '${devices.where((d) => d.status).length} ON',
                      style: TextStyle(color: Colors.deepPurple.shade700),
                    ),
                    SizedBox(width: 8),
                    Icon(Icons.power_settings_new, color: Colors.green),
                  ],
                ),
              ),
            ),

            SizedBox(height: 12),

            Expanded(
              child: GridView.builder(
                itemCount: devices.length,
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: crossAxisCount,
                  childAspectRatio: 1.05,
                  crossAxisSpacing: 12,
                  mainAxisSpacing: 12,
                ),
                itemBuilder: (context, i) {
                  final device = devices[i];
                  return DeviceCard(
                    device: device,
                    iconData: _iconForType(device.type),
                    onToggle: (bool value) async {
                      setState(() => device.status = value);
                      await _saveDevices();
                    },
                    onTap: () async {
                      await Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => DeviceDetailScreen(device: device)),
                      );
                      await _saveDevices();
                      setState(() {});
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),

      floatingActionButton: FloatingActionButton(
        onPressed: _openAddDevice,
        child: Icon(Icons.add),
      ),
    );
  }
}
