// lib/widgets/device_card.dart
import 'package:flutter/material.dart';
import 'modeldevice.dart';

class DeviceCard extends StatefulWidget {
  final Device device;
  final IconData iconData;
  final ValueChanged<bool> onToggle;
  final VoidCallback onTap;

  DeviceCard({
    Key? key,
    required this.device,
    required this.iconData,
    required this.onToggle,
    required this.onTap,
  }) : super(key: key);

  @override
  DeviceCardState createState() => DeviceCardState();
}

class DeviceCardState extends State<DeviceCard> with SingleTickerProviderStateMixin {
  double _scale = 1.0;

  void _onTapDown(TapDownDetails details) => setState(() => _scale = 0.97);
  void _onTapUp(TapUpDetails details) => setState(() => _scale = 1.0);
  void _onTapCancel() => setState(() => _scale = 1.0);

  @override
  Widget build(BuildContext context) {
    final d = widget.device;

    return GestureDetector(
      onTapDown: _onTapDown,
      onTapUp: _onTapUp,
      onTapCancel: _onTapCancel,

      child: AnimatedScale(
        scale: _scale,
        duration: Duration(milliseconds: 120),

        child: Card(
          child: InkWell(
            borderRadius: BorderRadius.circular(14),
            onTap: widget.onTap,

            child: Padding(
              padding: const EdgeInsets.all(12.0),

              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Hero(
                        tag: 'device_icon_${d.name}',
                        child: Container(
                          padding: EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            color: d.status
                                ? Colors.deepPurple.shade50
                                : Colors.grey.shade200,
                          ),
                          child: Icon(
                            widget.iconData,
                            size: 28,
                            color: d.status
                                ? Colors.deepPurple.shade600
                                : Colors.grey,
                          ),
                        ),
                      ),

                      SizedBox(width: 10),

                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(d.name,
                                style: TextStyle(
                                  fontWeight: FontWeight.w700,
                                  color: Colors.deepPurple.shade800,
                                )),
                            SizedBox(height: 4),
                            Text(
                              d.type,
                              style: TextStyle(
                                fontSize: 12,
                                color: Colors.deepPurple.shade400,
                              ),
                            ),
                          ],
                        ),
                      ),

                      Switch(
                        activeColor: Colors.deepPurple,
                        value: d.status,
                        onChanged: (v) {
                          widget.onToggle(v);
                          setState(() {});
                        },
                      ),
                    ],
                  ),

                  Spacer(),

                  Text(
                    d.status
                        ? '${d.type} is ON'
                        : '${d.type} is OFF',
                    style: TextStyle(
                      fontSize: 13,
                      color: Colors.deepPurple.shade900,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
