// lib/screens/device_detail_screen.dart
import 'package:flutter/material.dart';
import 'modeldevice.dart';

class DeviceDetailScreen extends StatefulWidget {
  final Device device;

  DeviceDetailScreen({Key? key, required this.device}) : super(key: key);

  @override
  DeviceDetailScreenState createState() => DeviceDetailScreenState();
}

class DeviceDetailScreenState extends State<DeviceDetailScreen> {
  @override
  Widget build(BuildContext context) {
    final d = widget.device;

    String labelForType() {
      switch (d.type) {
        case 'Fan':
          return 'Speed';
        case 'AC':
          return 'Temperature';
        case 'Camera':
          return 'Quality';
        default:
          return 'Brightness';
      }
    }

    double sliderMin() => d.type == 'AC' ? 16 : 0;
    double sliderMax() => d.type == 'AC' ? 30 : 100;

    return Scaffold(
      appBar: AppBar(
        title: Text(d.name),
        leading: BackButton(),
      ),

      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    Hero(
                      tag: 'device_icon_${d.name}',
                      child: Container(
                        width: 96,
                        height: 96,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(12),
                          color: Colors.deepPurple.withOpacity(0.08),
                        ),
                        child: Icon(
                          _iconForType(d.type),
                          size: 56,
                          color: Colors.deepPurple.shade600,
                        ),
                      ),
                    ),
                    SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(d.name, style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
                          SizedBox(height: 6),
                          Text('Type: ${d.type}'),
                          SizedBox(height: 6),
                          Text('Status: ${d.status ? 'ON' : 'OFF'}'),
                        ],
                      ),
                    )
                  ],
                ),
              ),
            ),

            SizedBox(height: 18),

            if (d.type != 'Camera')
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(labelForType(), style: TextStyle(fontWeight: FontWeight.w600)),
                      Row(
                        children: [
                          Expanded(
                            child: Slider(
                              activeColor: Colors.deepPurple.shade600,
                              thumbColor: Colors.deepPurple.shade500,
                              value: d.intensity,
                              min: sliderMin(),
                              max: sliderMax(),
                              divisions: (sliderMax() - sliderMin()).round(),
                              onChanged: (v) => setState(() => d.intensity = v),
                            ),
                          ),
                          SizedBox(width: 12),
                          Container(
                            width: 48,
                            alignment: Alignment.center,
                            child: Text(d.intensity.round().toString()),
                          )
                        ],
                      )
                    ],
                  ),
                ),
              ),

            Spacer(),

            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    icon: Icon(Icons.power_settings_new),
                    label: Text(d.status ? 'Turn Off' : 'Turn On'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.deepPurple.shade600,
                      foregroundColor: Colors.white,
                    ),
                    onPressed: () => setState(() => d.status = !d.status),
                  ),
                ),
                SizedBox(width: 12),
                OutlinedButton(
                  onPressed: () => Navigator.pop(context),
                  child: Text('Back'),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }

  IconData _iconForType(String t) {
    switch (t) {
      case 'Light':
        return Icons.lightbulb_outline;
      case 'Fan':
        return Icons.toys;
      case 'AC':
        return Icons.ac_unit;
      case 'Camera':
        return Icons.videocam;
      default:
        return Icons.devices_other;
    }
  }
}
