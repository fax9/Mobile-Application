// lib/screens/add_device_screen.dart
import 'package:flutter/material.dart';
import 'modeldevice.dart';

class AddDeviceScreen extends StatefulWidget {
  AddDeviceScreen({Key? key}) : super(key: key);

  @override
  AddDeviceScreenState createState() => AddDeviceScreenState();
}

class AddDeviceScreenState extends State<AddDeviceScreen> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _roomController = TextEditingController();

  String? _selectedType = 'Light';
  bool _status = false;

  final List<String> deviceTypes = ['Light', 'Fan', 'AC', 'Camera'];

  @override
  void dispose() {
    _nameController.dispose();
    _roomController.dispose();
    super.dispose();
  }

  void _submit() {
    final name = _nameController.text.trim();
    final room = _roomController.text.trim();
    if (name.isEmpty || room.isEmpty || _selectedType == null) return;

    final Device d = Device(
      name: '$name ($room)',
      type: _selectedType!,
      status: _status,
      intensity: _selectedType == 'AC'
          ? 22.0
          : (_selectedType == 'Camera'
          ? 100.0
          : 50.0),
    );

    Navigator.pop(context, d);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Add New Device'),
      ),

      body: Padding(
        padding: const EdgeInsets.all(16.0),

        child: Column(
          children: [
            TextField(
              controller: _nameController,
              decoration: InputDecoration(
                labelText: 'Device Name',
                border: OutlineInputBorder(),
              ),
            ),

            SizedBox(height: 12),

            TextField(
              controller: _roomController,
              decoration: InputDecoration(
                labelText: 'Room (e.g., Living Room)',
                border: OutlineInputBorder(),
              ),
            ),

            SizedBox(height: 12),

            DropdownButtonFormField<String>(
              value: _selectedType,
              decoration: InputDecoration(
                border: OutlineInputBorder(),
                labelText: 'Device Type',
              ),
              items: deviceTypes
                  .map((t) => DropdownMenuItem(
                value: t,
                child: Text(t),
              ))
                  .toList(),
              onChanged: (v) => setState(() => _selectedType = v),
            ),

            SizedBox(height: 12),

            SwitchListTile(
              title: Text('Turn ON by default'),
              activeColor: Colors.deepPurple,
              value: _status,
              onChanged: (v) => setState(() => _status = v),
            ),

            Spacer(),

            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => Navigator.pop(context),
                    child: Text('Cancel'),
                  ),
                ),

                SizedBox(width: 12),

                Expanded(
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.deepPurple.shade600,
                      foregroundColor: Colors.white,
                    ),
                    onPressed: _submit,
                    child: Text('Add Device'),
                  ),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
