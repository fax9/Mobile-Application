// lib/main.dart
import 'package:flutter/material.dart';
import 'dashboardscreen.dart';

void main() {
  runApp(SmartHomeApp());
}

class SmartHomeApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Smart Home Dashboard',
      debugShowCheckedModeBanner: false,

      // -----------------------------------------------------
      //                    THEME DATA
      // -----------------------------------------------------
      theme: ThemeData(
        useMaterial3: true,   // 🔥 IMPORTANT for new Flutter versions
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blueGrey),

        scaffoldBackgroundColor: const Color(0xFFF6F8FB),

        // ------------------ APP BAR ------------------------
        appBarTheme: AppBarTheme(
          elevation: 2,
          backgroundColor: Colors.white,
          iconTheme: IconThemeData(color: Colors.blueGrey.shade700),
          titleTextStyle: TextStyle(
            color: Colors.blueGrey.shade800,
            fontSize: 20,
            fontWeight: FontWeight.w600,
          ),
        ),

        // ------------------ FLOATING ACTION BUTTON ------------------------
        floatingActionButtonTheme: const FloatingActionButtonThemeData(
          backgroundColor: Colors.blueGrey,
          foregroundColor: Colors.white,
        ),

        // ------------------ CARD THEME ------------------------
        cardTheme: const CardThemeData(
          color: Colors.white,
          elevation: 3,
          shadowColor: Colors.black12,
          margin: EdgeInsets.all(8),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(14)),
          ),
        ),

        // ------------------ TEXT THEME (Material 3 names) ------------------------
        textTheme: TextTheme(
          titleLarge: TextStyle(
            color: Colors.blueGrey.shade800,
            fontSize: 20,
            fontWeight: FontWeight.w600,
          ),
          bodyMedium: TextStyle(
            color: Colors.blueGrey.shade900,
            fontSize: 14,
          ),
        ),

        dividerColor: Colors.grey.shade300,
      ),

      home: DashboardScreen(),
    );
  }
}
