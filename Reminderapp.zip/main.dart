import 'package:flutter/material.dart';
import 'loginScreen.dart';
import 'HomeScreen.dart';
import 'HistoryScreen.dart';

void main() {
  runApp( ReminderApp());
}

class ReminderApp extends StatelessWidget {
   ReminderApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Reminder App',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(primarySwatch: Colors.blue),
      home:  LoginScreen(),
    );
  }
}
