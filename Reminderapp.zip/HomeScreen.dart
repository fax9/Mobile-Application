import 'package:flutter/material.dart';
import 'dart:async';
import 'HistoryScreen.dart';

class HomeScreen extends StatefulWidget {
  final String username;

  HomeScreen({super.key, required this.username});

  @override
  State<HomeScreen> createState() => HomeScreenState();
}

class HomeScreenState extends State<HomeScreen> with SingleTickerProviderStateMixin {

  TextEditingController taskController = TextEditingController();
  TextEditingController timeController = TextEditingController();

  List<Map<String, String>> tasks = [];

  late AnimationController animationController;
  late Animation<double> fadeAnimation;

  @override
  void initState() {
    super.initState();
    animationController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 1),
    );

    fadeAnimation = CurvedAnimation(
      parent: animationController,
      curve: Curves.easeIn,
    );

    animationController.forward();
  }

  @override
  void dispose() {
    animationController.dispose();
    super.dispose();
  }

  void addTask() {
    String taskName = taskController.text;
    String timeText = timeController.text;

    if (taskName.isEmpty || timeText.isEmpty) {
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: Text("Missing Information"),
          content: Text("Please enter both task name and time in minutes."),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text("OK"),
            ),
          ],
        ),
      );
      return;
    }

    int? minutes = int.tryParse(timeText);
    if (minutes == null || minutes <= 0) {
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: Text("Invalid Time"),
          content: Text("Please enter a valid number of minutes."),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text("OK"),
            ),
          ],
        ),
      );
      return;
    }

    setState(() {
      tasks.add({
        'task': taskName,
        'time': '$minutes min',
        'status': 'Pending',
      });
    });

    int index = tasks.length - 1;
    Timer(Duration(minutes: minutes), () {
      if (mounted && tasks[index]['status'] == 'Pending') {
        setState(() {
          tasks[index]['status'] = 'Expired';
        });
      }
    });

    taskController.clear();
    timeController.clear();
  }

  void markComplete(int index) {
    setState(() {
      tasks[index]['status'] = 'Completed';
    });
  }

  void markExpired(int index) {
    setState(() {
      tasks[index]['status'] = 'Expired';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF6F6F9),

      appBar: AppBar(
        title: Text(
          "My Tasks",
          style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.deepPurple,
        centerTitle: true,
      ),

      drawer: Drawer(
        backgroundColor: Colors.white,
        child: ListView(
          children: [
            DrawerHeader(
              decoration: BoxDecoration(color: Colors.deepPurple),
              child: Center(
                child: Text(
                  "Menu",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
            ListTile(
              leading: Icon(Icons.home, color: Colors.deepPurple),
              title: Text("Home"),
              onTap: () => Navigator.pop(context),
            ),
            ListTile(
              leading: Icon(Icons.history, color: Colors.deepPurple),
              title: Text("History"),
              onTap: () {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                    builder: (context) => HistoryScreen(tasks: tasks),
                  ),
                );
              },
            ),
          ],
        ),
      ),

      // Main body
      body: SafeArea(
        child: FadeTransition(
          opacity: fadeAnimation,
          child: Padding(
            padding: EdgeInsets.all(18.0),
            child: Column(
              children: [
                SizedBox(height: 10),
                Text(
                  "Welcome!",
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    color: Colors.deepPurple,
                  ),
                ),
                SizedBox(height: 20),

                Container(
                  padding: EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black26,
                        blurRadius: 8,
                        offset: Offset(0, 3),
                      ),
                    ],
                  ),
                  child: Column(
                    children: [
                      TextField(
                        controller: taskController,
                        decoration: InputDecoration(
                          labelText: "Enter Task Name",
                          labelStyle: TextStyle(color: Colors.deepPurple),
                          filled: true,
                          fillColor: Color(0xFFF3E5F5),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(15),
                          ),
                        ),
                      ),
                      SizedBox(height: 12),
                      TextField(
                        controller: timeController,
                        keyboardType: TextInputType.number,
                        decoration: InputDecoration(
                          labelText: "Enter Time (in minutes)",
                          labelStyle: TextStyle(color: Colors.deepPurple),
                          filled: true,
                          fillColor: Color(0xFFF3E5F5),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(15),
                          ),
                        ),
                      ),
                      SizedBox(height: 15),
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton(
                          onPressed: addTask,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.deepPurple,
                            padding: EdgeInsets.symmetric(vertical: 12),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(15),
                            ),
                          ),
                          child: Text(
                            "Add Task",
                            style: TextStyle(color: Colors.white, fontSize: 18),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                SizedBox(height: 25),
                Text(
                  "Your Tasks",
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    color: Colors.deepPurple,
                  ),
                ),
                SizedBox(height: 10),

                Expanded(
                  child: tasks.isEmpty
                      ? Center(
                    child: Text(
                      "No tasks added yet.",
                      style: TextStyle(color: Colors.grey, fontSize: 16),
                    ),
                  )
                      : ListView.builder(
                    itemCount: tasks.length,
                    itemBuilder: (context, index) {
                      final task = tasks[index];
                      Color statusColor;

                      if (task['status'] == 'Completed') {
                        statusColor = Colors.green;
                      } else if (task['status'] == 'Expired') {
                        statusColor = Colors.red;
                      } else {
                        statusColor = Colors.orange;
                      }

                      return Card(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(15),
                        ),
                        elevation: 5,
                        margin: EdgeInsets.symmetric(vertical: 8),
                        child: ListTile(
                          title: Text(
                            task['task']!,
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                          subtitle: Text(
                            "Time: ${task['time']} | Status: ${task['status']}",
                            style: TextStyle(color: statusColor),
                          ),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              IconButton(
                                icon: Icon(Icons.done, color: Colors.green),
                                onPressed: () => markComplete(index),
                              ),
                              IconButton(
                                icon: Icon(Icons.close, color: Colors.red),
                                onPressed: () => markExpired(index),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
