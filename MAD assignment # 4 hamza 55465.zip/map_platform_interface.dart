// Conditional export: use the real google_maps_flutter on mobile/desktop,
// and lightweight stubs on the web to avoid web compilation errors.
export 'map_platform_mobile.dart' if (dart.library.html) 'map_platform_web.dart';
