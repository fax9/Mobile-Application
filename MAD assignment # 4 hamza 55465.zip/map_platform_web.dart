import 'package:flutter/material.dart';

// Minimal web stubs to avoid importing google_maps_flutter on the web.
// These provide the small subset of types the app uses.

class Marker {
  final MarkerId markerId;
  final LatLng position;
  Marker({required this.markerId, required this.position});
}

class MarkerId {
  final String value;
  const MarkerId(this.value);
}

class LatLng {
  final double latitude;
  final double longitude;
  LatLng(this.latitude, this.longitude);
}

class CameraPosition {
  final LatLng target;
  final double zoom;
  const CameraPosition({required this.target, required this.zoom});
}

class GoogleMapController {}

class GoogleMap extends StatelessWidget {
  final void Function(GoogleMapController)? onMapCreated;
  final CameraPosition initialCameraPosition;
  final Set markers;
  final bool myLocationEnabled;
  final bool myLocationButtonEnabled;

  const GoogleMap({
    this.onMapCreated,
    required this.initialCameraPosition,
    this.markers = const {},
    this.myLocationEnabled = false,
    this.myLocationButtonEnabled = false,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Render an empty container on web; MapWidget already shows a nicer placeholder.
    return Container();
  }
}
