// Conditional export: use the geolocator-based implementation on native
// platforms and a browser-based shim on web.
export 'location_service_mobile.dart' if (dart.library.html) 'location_service_web.dart';
