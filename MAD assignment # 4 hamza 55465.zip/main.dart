import 'package:flutter/material.dart';
import 'package:provider/provider.dart' as provider_pkg;
import 'package:http/http.dart' as http;
import 'providers/activity_provider.dart';
import 'repositories/activity_repository.dart';
import 'services/api_service.dart';
import 'services/storage_service.dart';
import 'screens/home_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return provider_pkg.MultiProvider(
      providers: [
        provider_pkg.Provider<ApiService>(create: (_) => ApiService(http.Client())),
        provider_pkg.Provider<StorageService>(create: (_) => StorageService()),
        provider_pkg.ProxyProvider2<ApiService, StorageService, ActivityRepository>(
          update: (_, apiService, storageService, __) => ActivityRepository(
            apiService: apiService,
            storageService: storageService,
          ),
        ),
        provider_pkg.ChangeNotifierProxyProvider<ActivityRepository, ActivityProvider>(
          create: (context) {
            final provider = ActivityProvider(
              ActivityRepository(
                apiService: ApiService(http.Client()),
                storageService: StorageService(),
              ),
            );
            // Fetch data on app startup
            provider.loadActivities();
            return provider;
          },
          update: (_, repository, previous) {
            previous = ActivityProvider(repository);
            previous.loadActivities();
            return previous;
          },
        ),
      ],
      child: MaterialApp(
        title: 'SmartTracker',
        theme: ThemeData(primarySwatch: Colors.blue, useMaterial3: true),
        home: const HomeScreen(),
        debugShowCheckedModeBanner: false,
      ),
    );
  }
}
