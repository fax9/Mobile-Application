import 'dart:async';
import 'dart:html' as html;

class Position {
  final double latitude;
  final double longitude;
  Position({required this.latitude, required this.longitude});
}

class LocationService {
  Future<Position> getCurrentLocation() async {
    final completer = Completer<Position>();

    if (html.window.navigator.geolocation == null) {
      completer.completeError(Exception('Geolocation not available in browser'));
      return completer.future;
    }

    html.window.navigator.geolocation!.getCurrentPosition().then((pos) {
      final lat = (pos.coords!.latitude as num).toDouble();
      final lon = (pos.coords!.longitude as num).toDouble();
      completer.complete(Position(latitude: lat, longitude: lon));
    }).catchError((e) {
      completer.completeError(Exception('Failed to get browser geolocation: $e'));
    });

    return completer.future;
  }

  Stream<Position> getLocationStream() async* {
    // Browser geolocation watchPosition API can be used, but for simplicity
    // provide a single value stream. Implementing watchPosition would require
    // more plumbing; this is sufficient for basic web behavior.
    try {
      final pos = await getCurrentLocation();
      yield pos;
    } catch (_) {
      // yield nothing on error
    }
  }
}
